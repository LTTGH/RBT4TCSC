#' hatS
#'
#' Return Kaplan-Meiter estimator at t=Time
#' @param sample a observed survival sample (X,delat), where X=min(T,C).
#' @param Time The time points at which that we want to estiamte, it can be avector or a signel time point. 
#' @return hatSKM The Kaplan-Meier estimator of survival function 
#' @import survival
#' @export
hatS=function(sample,Time){
  
  surFit=survfit(Surv(sample[,1],sample[,2])~1,error="greenwood")
  surEst=stepfun(surFit$time,c(1,surFit$surv))
  
  # Estimate
  hatSKM=surEst(Time)
  return(hatSKM)
}
