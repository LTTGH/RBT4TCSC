#' ABC
#'
#' return test statistics T_n, upper alpha quantile of its bootstrap distribution,
#' and upper alpha quantile of its asymptotic distribution
#' @param sample1 testing data set
#' @param sample2 Results results from trainging results
#' @param tau   Time of interest
#' @param alpha   the significant level 
#' @return res  The value of Tn, quantileBootTn quantileZ
#' @import survival MASS
#' @export
#'
#'
ABC=function(sample1,sample2,tau,alpha)
{ 
  n1=dim(sample1)[1];n2=dim(sample2)[1];n=n1+n2
  
  # Failure time points for sample 1, sample2, and pooled samples
  failureTime1=sort(sample1[sample1[,2]==1,1])
  failureTime2=sort(sample2[sample2[,2]==1,1])
  pooledSample=rbind(sample1, sample2)
  pooledFailureTime=sort(pooledSample[pooledSample[,2]==1,1])
  pooledFailureTime = pooledFailureTime[pooledFailureTime < tau]
  numPooledFailure=length(pooledFailureTime)
  
  
  # fit survival curves by KM
  sur.fit1=survfit(Surv(sample1[,1],sample1[,2])~1,error="greenwood")
  sur.fit2=survfit(Surv(sample2[,1],sample2[,2])~1,error="greenwood")
  
  # create KM estimators by step function
  sur.est1=stepfun(sur.fit1$time,c(1,sur.fit1$surv))
  sur.est2=stepfun(sur.fit2$time,c(1,sur.fit2$surv))
  
  # Estimate S_j(t) at failure time points
  S1=sur.est1(pooledFailureTime);
  S2=sur.est2(pooledFailureTime);
  
  # gap time t_{i+1}-t_{i}
  gapTime=diff(c(pooledFailureTime,tau))
  
  # T_n=sqrt(n)*sum_{i=1}^{kn}|s1(t_i)-s2(t_i)|*(t_{i+1}-t_i)
  Tn=sqrt(n)*sum(abs(S1-S2)*gapTime)
  
  # quantile of Tn by bootstrapping
  B=2000; bootTn=rep(0,B)
  
  for(iB in 1:B){
    # make the bootstrap procedure replicable
    set.seed(iB)
    # Bootstrap sample 1
    bootSample1=sample1[sample(n1,replace = TRUE),]
    
    set.seed(-iB)
    # Bootstrap sample 2
    bootSample2=sample2[sample(n2,replace = TRUE),]
    
    # Tn*=sqrt(n)*sum_{i=1}^{kn}|{S1*(t_i)-S1(t_i)}-{S2*(t_i)-S2(t_i)}|*(t_{i+1}-t_i)
    bootTn[iB]=sqrt(n)*sum(abs( (hatS(bootSample1,pooledFailureTime)-S1)
                                -(hatS(bootSample2,pooledFailureTime)-S2) )*gapTime)
  } # end of for boot
  quantileBootTn=quantile(bootTn,(1-alpha)) 
  
  # quantile of Z
  
  ##Number at risk at failure time point
  Y1=sur.fit1$n.risk[sur.fit1$n.event>=1]
  Y2=sur.fit2$n.risk[sur.fit2$n.event>=1]
  
  ##Number of failure at failure time point
  deltaN1=sur.fit1$n.event[sur.fit1$n.event>=1] 
  deltaN2=sur.fit2$n.event[sur.fit2$n.event>=1]
  
  
  ## HatGamma(t_1),HatGamma(t_2),...,HatGamma(t_{kn})
  vecHatGamma=NULL
  for(i in 1:numPooledFailure){
    vecHatGamma[i]=hatGamma(pooledFailureTime[i],deltaN1,deltaN2,Y1,Y2,
                            failureTime1<=pooledFailureTime[i],failureTime2<=pooledFailureTime[i],n)}
  
  ## Generate the multivariate normal distribution
  
  ##The Covariance matrix Sigma=Hat_Gamma(min(t_i,t_j))
  Sigma=matrix(0,numPooledFailure,numPooledFailure)
  for(i in 1:numPooledFailure){
    for(j in i:numPooledFailure){
      Sigma[i,j]=vecHatGamma[i];Sigma[j,i]=Sigma[i,j]}
  }
  
  ##Multivariate normal distribution N_{kn}(0,Sigma) (dimension of numPolledFailure), 
  ##Sample size is B 
  ##(B(hatGamma(t_1)),B(hatGamma(t_2)),...B(hatGamma(t_{kn})))
  set.seed(B)
  vecB=mvrnorm(B,rep(0,numPooledFailure),Sigma)
  
  ##Kaplan-Meier estimator based on the pooled samples
  pooledSur.fit=survfit(Surv(pooledSample[,1],pooledSample[,2])~1,error="greenwood")
  sur.est=stepfun(pooledSur.fit$time,c(1,pooledSur.fit$surv))
  
  ## Estimate S(t) based on plooed data at failure time points
  S=sur.est(pooledFailureTime)
  
  ##Estiamte Z, Z=sum_{j=1}^{k_n}abs(S(t_j)*B(hatGamma(t_j))*(t_{j+1}-t_{j}))
  vecHatZ=abs(matrix(S,1)[rep(1,B),]*vecB)%*%gapTime
  
  ##(1-alpha)quantile
  quantileZ=quantile(vecHatZ,(1-alpha))
  
  return(res=list(Tn=Tn,quantileBootTn=quantileBootTn,quantileZ=quantileZ))
}