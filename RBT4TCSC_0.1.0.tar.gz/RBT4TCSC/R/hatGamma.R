#' hatGamma
#'
#' Compute hatGamma(t)=n*sum_{t_1<=t}[DeltaN1(t_i)/{(Y1(t_i)-DeltaN1(t_i))*Y1(t_i)}
#'                            +DeltaN2(t_i)/{(Y2(t_i)-DeltaN2(t_i))*Y2(t_i)}]  
#' @param t is the given time 
#' @param deltaN1  Number of failure at failure time point of sample 1
#' @param deltaN2  Number of failure at failure time point of sample 2
#' @param Y1       Number of at risk at failure time point of sample 1
#' @param index1  Failure time points of sample 1 that less or equal to t
#' @param index2  Failure time points of sample 2 that less or equal to t
#' @param n       number of pooled sample sizes
#' @return hatGamma_t  The value of Tn, quantileBootTn quantileZ
#' @import survival
#' @export
#'
#'
hatGamma=function(t,deltaN1,deltaN2,Y1,Y2,index1,index2,n){
  
  ## Gamma1t=sum_{t_i<=t}[DeltaN1(t_i)/{(Y1(t_i)-DeltaN1(t_i))*Y1(t_i)}]
  gamma1t=deltaN1[index1]/((Y1[index1]-deltaN1[index1])*Y1[index1])
  ## Gamma2t=sum_{t_i<=t}[DeltaN2(t_i)/{(Y2(t_i)-DeltaN2(t_i))*Y2(t_i)}]
  gamma2t=deltaN2[index2]/((Y2[index2]-deltaN2[index2])*Y2[index2])
  ## Adjust the infinity value to 0
  gamma1t[gamma1t==Inf]=0
  gamma2t[gamma2t==Inf]=0
  
  hatGamma_t=n*(sum(gamma1t)+sum(gamma2t))
  return(hatGamma_t)}