#' LinStatABC
#' 
#' Return  stat_Lin
#' @param sample1 Sample 1=(X1,delta1)
#' @param sample2 Sample 2=(X2,delta2)
#' @return stat_Lin the statistics of Lin and xu
#' @import survival
#' @export
#'   
LinStatABC<-function(sample1,sample2)
{  # fit survival curves by KM
  sur.fit1=survfit(Surv(sample1[,1],sample1[,2])~1) #Greenwood is default
  sur.fit2=survfit(Surv(sample2[,1],sample2[,2])~1)
  
  # create KM estimators by step function
  sur.est1=stepfun(sur.fit1$time,c(1,sur.fit1$surv))
  sur.est2=stepfun(sur.fit2$time,c(1,sur.fit2$surv))
  
  # ordered event times
  pooledSample=rbind(sample1, sample2)
  event.time=sort(pooledSample[pooledSample[,2]==1,1])
  #event.time=sort(c(subset(sample1[,1],sample1[,2]==1),subset(sample2[,1],sample2[,2]==1)))
  
  #last time point (In paper Lin&Xun 10)
  sta1=subset(sample1,sample1[,1]==max(sample1[,1]))[2]  # last status of sample1 
  sta2=subset(sample2,sample2[,1]==max(sample2[,1]))[2]  # last status of sample2
  if(sta1==0&&sta2==0)
  {tau=min(max(sample1[,1]),max(sample2[,1]))}else{
    if(sta1==1&&sta2==1){tau=max(max(sample1[,1]),max(sample2[,1]))}else{
      tau=max(max(sample1[,1])*(1-sta1),max(sample2[,1])*(1-sta2))}} 
  
  # gap time t_{i+1}-t_{i}
  gapTime=diff(c(event.time[event.time<tau],tau))
  
  
  # compute Lin ABC statistic
  Lin_ABC=sum(abs(sur.est1(event.time[event.time<tau])-sur.est2(event.time[event.time<tau]))*gapTime)
  
  # The Greenwood standard error
  GW.std.error=function(samsize,surv,risk,event){
    sigma=NULL
    for(i in 1:samsize){
      S=0
      for(j in 1:i){S=S+event[j]/(risk[j]*(risk[j]-event[j]))}
      sigma[i]=surv[i]*sqrt(S)}
    return(sigma)
  }
  
  Sigma1=GW.std.error(samSize1,sur.fit1$surv,sur.fit1$n.risk,sur.fit1$n.event)
  Sigma2=GW.std.error(samSize2,sur.fit2$surv,sur.fit2$n.risk,sur.fit2$n.event)
  
  sigma.est1=stepfun(sort(sample1[,1]),c(0,Sigma1))  
  sigma.est2=stepfun(sort(sample2[,1]),c(0,Sigma2)) 
  
  # compute Lin ABC statistic expection 
  Sigma1=sigma.est1(event.time[event.time<tau]);Sigma2=sigma.est2(event.time[event.time<tau])
  Sigma1[is.na(Sigma1)]<-0;Sigma2[is.na(Sigma2)]<-0
  E_Lin_ABC=sum(sqrt(2/pi*(Sigma1^2+Sigma2^2))*gapTime)
  
  
  # compute Lin ABC statistic variance
  
  # compute covariance
  rho=1/2
  Cov=0
  L=length(gapTime)
  if (L>=2){
    for(j in 2:L)
    { 
      for(i in 1:(j-1)){
        Cov=Cov+2*rho*(gapTime[j])*(gapTime[i])*(1-2/pi)*
          sqrt((Sigma1[j]^2+Sigma2[j]^2)*(Sigma1[i]^2+Sigma2[i]^2))}}
  }else{Cov=0}
  
  # compute variance
  V_Lin_ABC=(1-2/pi)*sum((Sigma1^2+Sigma2^2)*(gapTime^2))+Cov
  
  # normal standardrization
  stat_Lin=(Lin_ABC-E_Lin_ABC)/sqrt(V_Lin_ABC)
  return(stat_Lin)
}